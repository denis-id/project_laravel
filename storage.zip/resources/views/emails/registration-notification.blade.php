<!DOCTYPE html>
<html>

<head>
    <title>Welcome to Our App</title>
</head>

<body>
    <h2>Hello, {{ $user->name }}</h2>
    <p>Thank you for registering with us!</p>
    <p>We're excited to have you on board.</p>
    <p>Best regards,<br>Our App Team</p>
</body>

</html>
