

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-4 px-4 relative">
        <h1
            class="text-4xl font-extrabold text-center mb-8 bg-gradient-to-r from-black to-blue-600 text-transparent bg-clip-text animate-pulse dark:text-white">
            Articles List</h1>
        <br>
        <!-- Search Bar -->
        <form method="GET" action="<?php echo e(route('articles.index')); ?>" class="mb-4 flex items-center space-x-2">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                class="w-full p-2 border border-gray-300 rounded-md shadow-sm dark:bg-gray-800 dark:text-white dark:border-gray-600"
                placeholder="Search Articles...">
            <button type="submit"
                class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 dark:bg-blue-700 dark:hover:bg-blue-600 transition">
                Search
            </button>
        </form>
        <?php if($articles->isEmpty()): ?>
            <div
                class="mt-4 p-4 bg-yellow-100 text-yellow-700 border border-yellow-300 rounded-lg dark:bg-yellow-900 dark:text-yellow-400">
                No Articles Found.
            </div>
        <?php else: ?>
            <div class="overflow-x-auto mt-6">
                <table class="w-full table-auto border border-gray-300 dark:border-gray-700 rounded-lg shadow-lg">
                    <thead>
                        <tr class="bg-blue-500 text-white dark:bg-blue-800">
                            <th class="px-4 py-3 text-left text-sm font-semibold">No</th>
                            <th class="px-4 py-3 w 1/6 text-left text-sm font-semibold">Image</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Title</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Slug</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Author</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Publish Date</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Featured</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Content</th>
                            <th class="px-4 py-3 text-left text-sm font-semibold">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr
                                class="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                                <td class="px-4 py-3 text-sm text-gray-700 dark:text-gray-300"><?php echo e($index + 1); ?></td>
                                <td class="px-4 py-3 w 1/6">
                                    <?php if($article->image_url): ?>
                                        <img src="<?php echo e($article->image_url); ?>" alt="Image for <?php echo e($article->title); ?>"
                                            class="w-14 h-14 object-cover rounded-md border border-gray-300 dark:border-gray-600">
                                    <?php else: ?>
                                        <span class="text-gray-500 dark:text-gray-400">No Image</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300"><?php echo e($article->title); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300"><?php echo e($article->slug); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300">
                                    <?php echo e($article->author ?? 'Tidak Diketahui'); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300">
                                    <?php echo e($article->published_at ? $article->published_at->format('d M Y') : 'Belum Diterbitkan'); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300">
                                    <?php echo e($article->is_featured ? 'Yes' : 'No'); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-800 dark:text-gray-300 max-w-xs">
                                    <div
                                        class="h-16 overflow-y-auto p-2 border border-gray-300 dark:border-gray-600 rounded bg-gray-50 dark:bg-gray-800">
                                        <?php echo e(Str::limit($article->content, 100, '...')); ?>

                                    </div>
                                </td>
                                <td class="px-4 py-3 text-sm flex space-x-2">
                                    <a href="<?php echo e(route('articles.show', $article->id)); ?>"
                                        class="text-blue-500 hover:text-blue-700 transition">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('articles.edit', $article->id)); ?>"
                                        class="text-yellow-500 hover:text-yellow-700 transition">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('articles.destroy', $article->id)); ?>" method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:text-red-700 transition"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus artikel ini?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('articles.create')); ?>"
            class="fixed bottom-4 right-6 hover:scale-105 px-5 py-3 bg-green-500 text-white rounded-full shadow-lg hover:bg-green-600 dark:bg-green-700 dark:hover:bg-green-600 transition">
            + Add New Article
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenov\OneDrive\Documents\laravel_bootcamp\resources\views/articles/index.blade.php ENDPATH**/ ?>