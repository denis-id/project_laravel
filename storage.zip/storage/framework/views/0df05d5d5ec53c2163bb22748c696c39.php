

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <div class="flex flex-col sm:flex-row items-center justify-between mb-6">
            <a href="<?php echo e(route('orders.index')); ?>"
                class="inline-flex items-center px-6 py-3 bg-blue-500 text-white font-bold rounded-2xl shadow-lg transform transition duration-500 hover:scale-110 mb-4 sm:mb-0">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                </svg>
                Back to Orders
            </a>
            <h1
                class="text-2xl sm:text-3xl font-extrabold text-center bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text animate-pulse">
                Detail Order #<?php echo e($order->id); ?></h1>
        </div>

        <div
            class="bg-gradient-to-br from-white to-blue-100 shadow-2xl rounded-2xl p-6 sm:p-8 transition-transform duration-500 hover:scale-105 dark:from-gray-800 dark:to-gray-900 dark:text-white">
            <div class="space-y-4">
                <p><strong>Name:</strong> <?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></p>
                <p><strong>Email:</strong> <?php echo e($order->email); ?></p>
                <p><strong>Address:</strong> <?php echo e($order->address); ?>, <?php echo e($order->city); ?>, <?php echo e($order->country); ?></p>
                <p><strong>Postal Code:</strong> <?php echo e($order->postal_code); ?></p>
                <p><strong>Payment Channel:</strong> <?php echo e($order->payment_channel); ?></p>
                <p><strong>Payment Method:</strong> <?php echo e($order->payment_method); ?></p>
                <p><strong>Total Price:</strong> Rp<?php echo e(number_format($order->price, 0, ',', '.')); ?></p>
                <p><strong>Status:</strong> <?php echo e($order->status); ?></p>
                <p><strong>Created At:</strong> <?php echo e($order->created_at); ?></p>
            </div>

            <div class="mt-8">
                <h2 class="text-xl font-bold text-blue-700 dark:text-blue-300">Products in this Order:</h2>
                <ul class="space-y-4 mt-4">
                    <?php if($order->orderProducts->isNotEmpty()): ?>
                        <?php $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li
                                class="bg-gradient-to-r from-blue-100 to-blue-200 p-4 rounded-lg dark:from-blue-800 dark:to-blue-900">
                                <p><strong>Product:</strong>
                                    <?php echo e($orderProduct->productVariant->product->name ?? 'Unknown Product'); ?></p>
                                <p><strong>Size:</strong> <?php echo e($orderProduct->productVariant->size ?? '-'); ?></p>
                                <p><strong>Quantity:</strong> <?php echo e($orderProduct->quantity); ?></p>
                                <p><strong>Price:</strong> Rp<?php echo e(number_format($orderProduct->price, 0, ',', '.')); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="bg-yellow-100 text-yellow-800 p-4 rounded-lg dark:bg-yellow-900 dark:text-yellow-200">
                            <?php echo e($order->products_name ?? 'No product details available'); ?>

                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenov\OneDrive\Documents\laravel_bootcamp\resources\views/orders/show.blade.php ENDPATH**/ ?>