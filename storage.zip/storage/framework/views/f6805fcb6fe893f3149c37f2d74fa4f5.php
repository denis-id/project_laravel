

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-8 px-4">
        <!-- Back to Articles Button -->
        <div class="col-span-full">
            <a href="<?php echo e(route('articles.index')); ?>"
                class="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-white transition-all rounded-lg bg-gradient-to-r from-purple-500 to-pink-600 shadow-lg hover:shadow-xl hover:from-purple-600 hover:to-pink-700 transform hover:-translate-y-1">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Articles
            </a>
        </div>

        <!-- Article Header -->
        <div class="max-w-3xl mx-auto mt-8">
            <h1 class="text-4xl font-semibold text-gray-800 dark:text-white"><?php echo e($article->title); ?></h1>
            <p class="mt-2 text-lg text-gray-600 dark:text-gray-300">
                <strong>Penulis:</strong> <?php echo e($article->author ?? 'Tidak Diketahui'); ?> |
                <strong>Tanggal Terbit:</strong>
                <?php echo e($article->published_at ? $article->published_at->format('d M Y') : 'Belum Diterbitkan'); ?>

            </p>
        </div>

        <!-- Article Image (Smaller Size) -->
        <?php if($article->image_url): ?>
            <div class="mt-6 max-w-3xl mx-auto">
                <img src="<?php echo e($article->image_url); ?>" alt="Image for <?php echo e($article->title); ?>"
                    class="w-full max-w-md mx-auto object-cover rounded-lg shadow-md">
            </div>
        <?php else: ?>
            <div class="mt-6 text-center text-gray-500 dark:text-gray-400">Tidak ada gambar untuk artikel ini</div>
        <?php endif; ?>

        <!-- Article Excerpt -->
        <?php if($article->excerpt): ?>
            <div class="max-w-3xl mx-auto mt-8 text-gray-700 dark:text-gray-300">
                <h2 class="text-2xl font-semibold">Excerpt:</h2>
                <p><?php echo e($article->excerpt); ?></p>
            </div>
        <?php endif; ?>

        <!-- Article Content -->
        <div class="max-w-3xl mx-auto mt-8 text-gray-700 dark:text-gray-300">
            <div class="prose prose-lg dark:prose-dark">
                <h2 class="text-2xl font-semibold">Content:</h2>
                <?php echo $article->content; ?>

            </div>
        </div>

        <!-- Featured Status -->
        <div class="max-w-3xl mx-auto mt-8">
            <p class="text-lg text-gray-700 dark:text-gray-300">
                <strong>Status Featured:</strong> <?php echo e($article->is_featured ? 'Ya' : 'Tidak'); ?>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenov\OneDrive\Documents\laravel_bootcamp\resources\views/articles/show.blade.php ENDPATH**/ ?>