<!DOCTYPE html>
<html>

<head>
    <title>Product PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
        }

        .info {
            margin: 20px auto;
            width: 50%;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
        }

        .info img {
            display: block;
            margin: 0 auto 20px auto;
            max-width: 100px;
            border-radius: 8px;
        }

        .variant {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <h1>Product Details</h1>
    <div class="info">
        <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
        <p><strong>Name:</strong> <?php echo e($product->name); ?></p>
        <p><strong>Status:</strong> <?php echo e($product->is_active ? 'Active' : 'Inactive'); ?></p>
        <p><strong>Category:</strong> <?php echo e($product->category->name); ?></p>
        <p><strong>Description:</strong> <?php echo e($product->description); ?></p>

        <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="variant">
                <h3>Variants:</h3>
                <p><strong>Size:</strong> <?php echo e($variant['size']); ?></p>
                <p><strong>Stock:</strong> <?php echo e($variant['stock']); ?></p>
                <p><strong>Price:</strong> <?php echo e($variant['price']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>

</html>
<?php /**PATH C:\Users\lenov\OneDrive\Documents\laravel_bootcamp\resources\views/products/pdf.blade.php ENDPATH**/ ?>